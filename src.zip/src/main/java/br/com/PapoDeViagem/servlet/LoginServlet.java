package br.com.PapoDeViagem.servlet;

import br.com.PapoDeViagem.dao.UsuarioDao;
import br.com.PapoDeViagem.model.Login;
import br.com.PapoDeViagem.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String senha = req.getParameter("senha");
        String redirect = req.getParameter("redirect"); // Novo parâmetro

        System.out.println("Tentativa de login: " + email);
        System.out.println("Redirect parameter: " + redirect);

        Login login = new Login(email, senha);
        UsuarioDao usuarioDao = new UsuarioDao();
        boolean valido = usuarioDao.login(login);

        if (valido) {
            HttpSession session = req.getSession();
            Usuario usuario = usuarioDao.obterUsuarioPorEmail(email);

            if (usuario != null) {
                session.setAttribute("usuarioLogado", usuario);
                System.out.println("Usuário logado: " + usuario.getNome() + ", Grupo: " + usuario.getId_grupo());

                // Verifica se veio do backoffice
                if ("backoffice".equals(redirect)) {
                    if (usuarioDao.podeAcessarBackOffice(email)) {
                        System.out.println("Redirecionando para backoffice/dashboard.jsp");
                        resp.sendRedirect("backoffice/dashboard.jsp");
                    } else {
                        System.out.println("Usuário não tem permissão para backoffice");
                        resp.sendRedirect("backoffice/login-backoffice.jsp?error=1");
                    }
                } else {
                    // Login normal do site
                    System.out.println("Redirecionando para index.html");
                    resp.sendRedirect("index.html");
                }
            } else {
                System.out.println("Usuário não encontrado após login válido");
                req.setAttribute("erroLogin", "Erro ao carregar dados do usuário!");
                req.getRequestDispatcher("login.jsp").forward(req, resp);
            }

        } else {
            System.out.println("Login inválido para: " + email);

            if ("backoffice".equals(redirect)) {
                resp.sendRedirect("backoffice/login-backoffice.jsp?error=1");
            } else {
                req.setAttribute("erroLogin", "Usuário ou senha incorretos!");
                req.getRequestDispatcher("login.jsp").forward(req, resp);
            }
        }
    }
}