package br.com.PapoDeViagem.servlet;

import br.com.PapoDeViagem.dao.UsuarioDao;
import br.com.PapoDeViagem.model.Usuario;
import br.com.PapoDeViagem.util.SecurityUtil;
import br.com.PapoDeViagem.util.ValidadorCPF;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/registro")
public class CadastroServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String senha = request.getParameter("senha");
        String confirmacaoSenha = request.getParameter("confirmacaoSenha");
        String data_nascimento = request.getParameter("data_nascimento");
        String cpf = request.getParameter("cpf");

        UsuarioDao dao = new UsuarioDao();

        // Validação de email existente
        if (dao.emailExiste(email)) {
            request.setAttribute("erro", "Email já cadastrado!");
            request.getRequestDispatcher("registro.jsp").forward(request, response);
            return;
        }

        // Validação de formato de email
        if (!email.contains("@") || !email.contains(".")) {
            request.setAttribute("erro", "Email inválido!");
            request.getRequestDispatcher("registro.jsp").forward(request, response);
            return;
        }

        // Validação da confirmação de senha
        if (!senha.equals(confirmacaoSenha)) {
            request.setAttribute("erro", "As senhas não coincidem!");
            request.getRequestDispatcher("registro.jsp").forward(request, response);
            return;
        }

        // Validação de tamanho mínimo da senha
        if (senha.length() < 8) {
            request.setAttribute("erro", "A senha deve ter no mínimo 8 caracteres!");
            request.getRequestDispatcher("registro.jsp").forward(request, response);
            return;
        }

        // ✅ VALIDAÇÃO DO CPF (NOVO!)
        if (!ValidadorCPF.validar(cpf)) {
            request.setAttribute("erro", "CPF inválido!");
            request.getRequestDispatcher("registro.jsp").forward(request, response);
            return;
        }

        // Cria usuário com senha hasheada e CPF formatado
        Usuario usuario = new Usuario();
        usuario.setNome(nome);
        usuario.setEmail(email);
        usuario.setSenha(SecurityUtil.hashPassword(senha));
        usuario.setData_nascimento(data_nascimento);
        usuario.setCpf(ValidadorCPF.formatar(cpf)); // CPF formatado
        usuario.setAdm(false);

        dao.criarUsuario(usuario);

        System.out.println("Usuário cadastrado com sucesso: " + email);
        response.sendRedirect("login.jsp");
    }
}