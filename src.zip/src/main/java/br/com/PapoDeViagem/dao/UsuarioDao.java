package br.com.PapoDeViagem.dao;

import br.com.PapoDeViagem.model.Login;
import br.com.PapoDeViagem.model.Usuario;
import br.com.PapoDeViagem.util.SecurityUtil;

import java.sql.*;

public class UsuarioDao {

    public void criarTabelaUsuario() {
        String SQLCriar = "CREATE TABLE IF NOT EXISTS USUARIO (" +
                "ID INT AUTO_INCREMENT PRIMARY KEY, " +
                "NOME VARCHAR(100), " +
                "EMAIL VARCHAR(100), " +
                "SENHA VARCHAR(100), " +
                "DATA_NASCIMENTO VARCHAR(20), " +
                "CPF VARCHAR(110), " +
                "ADM BOOLEAN DEFAULT FALSE, " +
                "ID_GRUPO INT, " +
                "STATUS ENUM('Ativo','Inativo') DEFAULT 'Ativo')";

        String BuscarAdm = "SELECT * FROM USUARIO WHERE EMAIL = 'adm@gmail.com'";

        try {
            Connection connection = DriverManager.getConnection("jdbc:h2:~/test", "sa", "sa");
            connection.prepareStatement(SQLCriar).execute();

            PreparedStatement checkAdm = connection.prepareStatement(BuscarAdm);
            ResultSet result = checkAdm.executeQuery();

            if (!result.next()) {
                // CORREÇÃO: Hash da senha deve ser feito fora da query
                String senhaAdminHash = SecurityUtil.hashPassword("admin");
                String adm = "INSERT INTO USUARIO (NOME, EMAIL, SENHA, CPF, DATA_NASCIMENTO, ADM, ID_GRUPO, STATUS) VALUES " +
                        "(?, ?, ?, ?, ?, ?, ?, ?)";

                PreparedStatement insertAdm = connection.prepareStatement(adm);
                insertAdm.setString(1, "ADM");
                insertAdm.setString(2, "adm@gmail.com");
                insertAdm.setString(3, senhaAdminHash);
                insertAdm.setString(4, "12345678910");
                insertAdm.setString(5, "2000-01-01");
                insertAdm.setBoolean(6, true);
                insertAdm.setInt(7, 1);
                insertAdm.setString(8, "Ativo");

                insertAdm.execute();
                System.out.println("Admin criado com senha hasheada: " + senhaAdminHash);
            } else {
                System.out.println("Admin já existe no banco");
            }

            connection.close();
            System.out.println("Tabela Usuario criada com sucesso!");

        } catch (Exception e) {
            System.out.println("fail in database connection");
            System.out.println(e);
        }
    }

    public void criarUsuario(Usuario usuario) {
        // CORREÇÃO: Adicionado ID_GRUPO na query
        String SQL = "INSERT INTO USUARIO (NOME, EMAIL, SENHA, DATA_NASCIMENTO, CPF, ADM, ID_GRUPO, STATUS) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection connection = DriverManager.getConnection("jdbc:h2:~/test", "sa", "sa");
            PreparedStatement preparedStatement = connection.prepareStatement(SQL);

            preparedStatement.setString(1, usuario.getNome());
            preparedStatement.setString(2, usuario.getEmail());
            preparedStatement.setString(3, usuario.getSenha());
            preparedStatement.setString(4, usuario.getData_nascimento());
            preparedStatement.setString(5, usuario.getCpf());
            preparedStatement.setBoolean(6, usuario.getAdm());
            preparedStatement.setInt(7, usuario.getId_grupo()); // CORREÇÃO: Adicionado ID_GRUPO
            preparedStatement.setString(8, "Ativo");

            int linhasAfetadas = preparedStatement.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Usuario Criado com Sucesso! Linhas afetadas: " + linhasAfetadas);
            } else {
                System.out.println("Nenhum usuário foi criado!");
            }

            connection.close();

        } catch (Exception e) {
            System.err.println("Erro ao criar usuário: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public boolean emailExiste(String email) {
        String SQL = "SELECT COUNT(*) FROM USUARIO WHERE EMAIL = ?";

        try {
            Connection connection = DriverManager.getConnection("jdbc:h2:~/test", "sa", "sa");
            PreparedStatement preparedStatement = connection.prepareStatement(SQL);
            preparedStatement.setString(1, email);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1) > 0;
            }
            connection.close();

        } catch (Exception e) {
            System.err.println("Erro ao verificar email: " + e.getMessage());
        }
        return false;
    }

    public boolean login(Login login) {
        String SQL = "SELECT SENHA FROM USUARIO WHERE EMAIL = ? AND STATUS = 'Ativo'";

        try (Connection connection = DriverManager.getConnection("jdbc:h2:~/test", "sa", "sa");
             PreparedStatement ps = connection.prepareStatement(SQL)) {

            ps.setString(1, login.getEmail());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String senhaHashDoBanco = rs.getString("SENHA");
                return SecurityUtil.checkPassword(login.getSenha(), senhaHashDoBanco);
            }

        } catch (Exception e) {
            System.err.println("Erro no login: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // NOVO MÉTODO: Verificar se usuário pode acessar backOffice
    public boolean podeAcessarBackOffice(String email) {
        String SQL = "SELECT ID_GRUPO FROM USUARIO WHERE EMAIL = ? AND STATUS = 'Ativo'";

        try (Connection connection = DriverManager.getConnection("jdbc:h2:~/test", "sa", "sa");
             PreparedStatement ps = connection.prepareStatement(SQL)) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int idGrupo = rs.getInt("ID_GRUPO");
                // Permite acesso para administrador (1) e estoquista (2)
                return idGrupo == 1 || idGrupo == 2;
            }

        } catch (Exception e) {
            System.err.println("Erro ao verificar acesso backOffice: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // NOVO MÉTODO: Obter informações completas do usuário após login
    public Usuario obterUsuarioPorEmail(String email) {
        String SQL = "SELECT * FROM USUARIO WHERE EMAIL = ? AND STATUS = 'Ativo'";
        Usuario usuario = null;

        try (Connection connection = DriverManager.getConnection("jdbc:h2:~/test", "sa", "sa");
             PreparedStatement ps = connection.prepareStatement(SQL)) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getInt("ID"));
                usuario.setNome(rs.getString("NOME"));
                usuario.setEmail(rs.getString("EMAIL"));
                usuario.setData_nascimento(rs.getString("DATA_NASCIMENTO"));
                usuario.setCpf(rs.getString("CPF"));
                usuario.setAdm(rs.getBoolean("ADM"));
                usuario.setId_grupo(rs.getInt("ID_GRUPO"));
            }

        } catch (Exception e) {
            System.err.println("Erro ao obter usuário: " + e.getMessage());
            e.printStackTrace();
        }
        return usuario;
    }

    public void deletarPorEmail(String email) {
        String sql = "DELETE FROM USUARIO WHERE email = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:h2:~/test", "sa", "sa");
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void verificarUsuarioAdmin() {
        String SQL = "SELECT * FROM USUARIO WHERE EMAIL = 'adm@gmail.com'";

        try (Connection connection = DriverManager.getConnection("jdbc:h2:~/test", "sa", "sa");
             PreparedStatement ps = connection.prepareStatement(SQL)) {

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("=== DADOS DO ADMIN ===");
                System.out.println("ID: " + rs.getInt("ID"));
                System.out.println("Nome: " + rs.getString("NOME"));
                System.out.println("Email: " + rs.getString("EMAIL"));
                System.out.println("Senha (hash): " + rs.getString("SENHA"));
                System.out.println("ID Grupo: " + rs.getInt("ID_GRUPO"));
                System.out.println("ADM: " + rs.getBoolean("ADM"));
                System.out.println("Status: " + rs.getString("STATUS"));
            } else {
                System.out.println("Admin não encontrado no banco!");
            }

        } catch (Exception e) {
            System.err.println("Erro ao verificar admin: " + e.getMessage());
        }
    }
}