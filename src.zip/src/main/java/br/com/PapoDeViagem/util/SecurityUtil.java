package br.com.PapoDeViagem.util;

import at.favre.lib.crypto.bcrypt.BCrypt;

public class SecurityUtil {

    public static String hashPassword(String senha) {
        return BCrypt.withDefaults().hashToString(12, senha.toCharArray());
    }

    public static boolean checkPassword(String senha, String hash) {
        BCrypt.Result result = BCrypt.verifyer().verify(senha.toCharArray(), hash);
        return result.verified;
    }
}