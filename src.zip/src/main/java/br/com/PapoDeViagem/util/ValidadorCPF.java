package br.com.PapoDeViagem.util;

public class ValidadorCPF {


    public static boolean validar(String cpf) {
        if (cpf == null || cpf.trim().isEmpty()) {
            return false;
        }


        cpf = cpf.replaceAll("[^0-9]", "");


        if (cpf.length() != 11) {
            return false;
        }


        if (cpf.matches("(\\d)\\1{10}")) {
            return false;
        }


        try {
            int digito1 = calcularDigito(cpf.substring(0, 9));
            int digito2 = calcularDigito(cpf.substring(0, 9) + digito1);

            return cpf.equals(cpf.substring(0, 9) + digito1 + digito2);
        } catch (NumberFormatException e) {
            return false;
        }
    }


    private static int calcularDigito(String parcial) {
        int soma = 0;
        int peso = parcial.length() + 1;

        for (int i = 0; i < parcial.length(); i++) {
            soma += Integer.parseInt(parcial.substring(i, i + 1)) * peso;
            peso--;
        }

        int resto = soma % 11;
        return resto < 2 ? 0 : 11 - resto;
    }


    public static String formatar(String cpf) {
        if (cpf == null || !validar(cpf)) {
            return cpf;
        }

        cpf = cpf.replaceAll("[^0-9]", "");
        return cpf.substring(0, 3) + "." + cpf.substring(3, 6) + "." +
                cpf.substring(6, 9) + "-" + cpf.substring(9, 11);
    }


    public static void main(String[] args) {
        // CPFs válidos
        System.out.println("CPF válido: " + validar("529.982.247-25")); // true
        System.out.println("CPF válido: " + validar("52998224725"));    // true

        // CPFs inválidos
        System.out.println("CPF inválido: " + validar("111.111.111-11")); // false
        System.out.println("CPF inválido: " + validar("123.456.789-00")); // false
        System.out.println("CPF inválido: " + validar(""));               // false
        System.out.println("CPF inválido: " + validar(null));             // false
    }
}