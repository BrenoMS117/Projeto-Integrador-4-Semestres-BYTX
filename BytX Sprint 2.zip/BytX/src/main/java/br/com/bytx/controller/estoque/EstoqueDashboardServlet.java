package br.com.bytx.controller.estoque;

public class EstoqueDashboardServlet {
}
