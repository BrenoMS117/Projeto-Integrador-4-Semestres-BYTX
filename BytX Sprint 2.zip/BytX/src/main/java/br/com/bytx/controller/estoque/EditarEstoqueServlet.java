package br.com.bytx.controller.estoque;

public class EditarEstoqueServlet {
}
